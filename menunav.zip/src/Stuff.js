import React, { Component } from "react";
 
class Stuff extends Component {
  render() {
    return (
      <div>
        <h2>STUFF</h2>
        <p>10 Awesome Things that India is Famous For</p>
        <ol>
          <li>Its diverse culture. India has a varied and diverse culture, which changes depending on where in the country you visit</li>
          <li>The Hindi Film Industry - Bollywood</li>
          <li>An old yet outstanding train network</li>
          <li>Colourful celebrations and festivals</li>
          <li>Its spiritual connection</li>
          <li>The large population</li>
          <li>Its sporting culture</li>
          <li>Delicious Indian food.</li>
        </ol>
      </div>
    );
  }
}
 
export default Stuff;